# thedadfirm-backend

## Documentation

### Description

RESTful backend service for The Dad Firm written in **Kotlin** with **Spring Boot** and **Postgres**.

This service is responsible for:

- Serving questionnaires from Yaml configuration files
- User CRUD operations
- Handling Passwordless Email Authentication, facilitated by Next-Auth on the frontend
- Storing answers to user questions
- Generating documents from user answers (TBD)

### Requirements

- JDK 17
- Docker (or Podman)
- make _(optional)_
- Insomnia API Client _(optional)_

### Database

A database connection is required to run this application.

#### Initial Setup

Simply run `make` from the project's root directory. Docker must be running.

Alternatively, run the command within the Makefile directly, replacing the
environment variables in the command with the values within the file.

#### Subsequent Start

Ensure docker is running, then run:

`docker start thedadfirm_db`

### Build

To build the project run:

`./gradlew build`

### Test

To test the project run:

`./gradlew test`

### Lint

When running this linter, it is recommended that you first run:

`./gradlew clean build`

This will automatically run the lint check and will fail if
the code style is not followed. To fix most formatting errors automatically:

`./gradlew ktlintformat`

Some issues, notably wildcard imports, will not be fixed automatically. You can
prevent wildcard imports in the settings for your IDE.

In Intellij, this is found under File > Settings > Code Style > Kotlin > Imports

### Run the project locally

With the database running, run:

`./gradlew bootrun`

An Insomnia collection can be found in the project's root. You can use this to interact with the service.
The thedadfirm-backend is required for thedadfirm-frontend to function properly.

### Working on a Ticket and Committing to this Repo

1. Checkout a new branch with your ticket number ex. `git checkout -b DF-15`
2. Write some code (and some tests, not necessarily in that order)
3. When ready to commit, run `./gradlew clean build`
4. Resolve any failures, including test failures and lint errors
5. Add your changes and commit with the following syntax:
   - `git commit -m "[DF-15][Cullen] my friendly and discriptive commit message"`
6. Push changes and repeat above steps until feature is complete
7. Create a PR and ensure that the CI checks pass
8. Merge the PR

### Notes

- This project was originally designed to run in a docker container. There currently is not a Dockerfile, as it is yet to be deployed
- The database should likely not be run as a docker container in production. Set the appropriate environment variables in the application.yml file
