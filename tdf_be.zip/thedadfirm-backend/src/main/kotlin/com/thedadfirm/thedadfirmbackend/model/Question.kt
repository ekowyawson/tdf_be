package com.thedadfirm.thedadfirmbackend.model

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonInclude.Include
import com.thedadfirm.thedadfirmbackend.exceptions.InvalidOptionsException
import com.thedadfirm.thedadfirmbackend.exceptions.InvalidQuestionException
import mu.KotlinLogging

@JsonInclude(Include.NON_EMPTY)
data class Question(
    val multipleChoiceQuestion: MultipleChoiceQuestion? = null,
    val shortAnswerQuestion: ShortAnswerQuestion? = null,
    val dropDownQuestion: DropDownQuestion? = null,
    val yesNoQuestion: YesNoQuestion? = null
) {
    init {
        validateQuestion()
    }

    private fun validateQuestion() {
        when {
            multipleChoiceQuestion != null -> {
                shortAnswerQuestion?.let {
                    throw InvalidQuestionException("Question object contains multiple valid questions")
                }
            }

            shortAnswerQuestion != null -> {
                dropDownQuestion?.let {
                    throw InvalidQuestionException("Question object contains multiple valid questions")
                }
            }

            dropDownQuestion != null -> {
                yesNoQuestion?.let {
                    throw InvalidQuestionException("Question object contains multiple valid questions")
                }
            }

            yesNoQuestion != null -> {
                return
            }

            else -> {
                throw throw InvalidQuestionException("Question object contains no valid questions")
            }
        }
        return
    }

    fun get(): CoreQuestion {
        multipleChoiceQuestion?.let { return it } ?: shortAnswerQuestion?.let { return it }
            ?: dropDownQuestion?.let { return it } ?: yesNoQuestion?.let { return it }
            ?: throw InvalidQuestionException("Question object contains no valid questions")
    }

    fun applyAnswer(answer: Answer) {
        this.get().applyAnswer(answer)
    }
}

data class SubQuestionnaireTrigger(
    val answerValue: String,
    val questionnaireName: String
)

@JsonInclude(Include.NON_EMPTY)
abstract class CoreQuestion {
    abstract val key: String
    abstract val questionText: String
    abstract var answer: Answer?
    abstract var commentary: String?
    abstract val actionOnAnswer: AnswerAction?
    abstract val triggerSubQuestionnaire: List<SubQuestionnaireTrigger>?
    abstract fun applyAnswer(answer: Answer)
}

data class MultipleChoiceQuestion(
    override val key: String,
    override val questionText: String,
    var options: List<String> = listOf(),
    val wrongOptions: List<String> = emptyList(),
    override val actionOnAnswer: AnswerAction? = null,
    override val triggerSubQuestionnaire: List<SubQuestionnaireTrigger>? = null,
    override var answer: Answer? = null,
    override var commentary: String? = null
) : CoreQuestion() {
    private val logger = KotlinLogging.logger {}

    init {
        validateWrongOptions()
    }

    override fun applyAnswer(answer: Answer) {
        options.find { option -> option == answer.value }?.let {
            this.answer = answer
        } ?: throw InvalidOptionsException(
            "${answer.value} is not an option",
            invalidOptions = listOf(answer.value),
            options
        )
    }

    private fun validateWrongOptions() {
        val invalidWrongOptions = mutableListOf<String>()
        wrongOptions.forEach { wrongOption ->
            if (!options.contains(wrongOption)) {
                invalidWrongOptions.add(wrongOption)
            }
        }
        if (invalidWrongOptions.isNotEmpty()) {
            logger.error { "Invalid options in ${this.questionText}" }
            throw InvalidOptionsException(
                "wrongOption(s) provided have values not present in options",
                invalidWrongOptions,
                options
            )
        }
    }
}

@JsonIgnoreProperties("failOnYes", "failOnNo", allowSetters = true)
data class YesNoQuestion(
    override val key: String,
    override val questionText: String,
    val failOnYes: Boolean = false,
    val failOnNo: Boolean = false,
    override val actionOnAnswer: AnswerAction? = null,
    override val triggerSubQuestionnaire: List<SubQuestionnaireTrigger>? = null,
    override var answer: Answer? = null,
    override var commentary: String? = null
) : CoreQuestion() {
    val wrongOptions = mutableListOf<String>()
    val options = listOf("Yes", "No")

    init {
        setWrongOption()
    }

    private fun setWrongOption() {
        if (failOnYes) {
            wrongOptions.add("Yes")
        }
        if (failOnNo) {
            wrongOptions.add("No")
        }
    }

    override fun applyAnswer(answer: Answer) {
        options.find { option -> option == answer.value }?.let {
            this.answer = answer
        } ?: throw InvalidOptionsException(
            "${answer.value} is not an option",
            invalidOptions = listOf(answer.value),
            options
        )
    }
}

data class DropDownQuestion(
    override val key: String,
    override val questionText: String,
    var options: List<String> = listOf(),
    val wrongOptions: List<String> = emptyList(),
    val isYesNoQuestion: Boolean = false,
    override val actionOnAnswer: AnswerAction? = null,
    override val triggerSubQuestionnaire: List<SubQuestionnaireTrigger>? = null,
    override var answer: Answer? = null,
    override var commentary: String? = null
) : CoreQuestion() {
    private val logger = KotlinLogging.logger {}

    init {
        if (isYesNoQuestion) {
            options = listOf("Yes", "No")
        }
        validateWrongOptions()
    }

    override fun applyAnswer(answer: Answer) {
        options.find { option -> option == answer.value }?.let {
            this.answer = answer
        } ?: throw InvalidOptionsException(
            "${answer.value} is not an option",
            invalidOptions = listOf(answer.value),
            options
        )
    }

    private fun validateWrongOptions() {
        val invalidWrongOptions = mutableListOf<String>()
        wrongOptions.forEach { wrongOption ->
            if (!options.contains(wrongOption)) {
                invalidWrongOptions.add(wrongOption)
            }
        }
        if (invalidWrongOptions.isNotEmpty()) {
            logger.error { "Invalid options in ${this.questionText}" }
            throw InvalidOptionsException(
                "wrongOption(s) provided have values not present in options",
                invalidWrongOptions,
                options
            )
        }
    }
}

data class ShortAnswerQuestion(
    override val key: String,
    override val questionText: String,
    val exampleInput: String = "",
    override val actionOnAnswer: AnswerAction? = null,
    override var answer: Answer? = null,
    override val triggerSubQuestionnaire: List<SubQuestionnaireTrigger>? = null,
    override var commentary: String? = null
) : CoreQuestion() {
    override fun applyAnswer(answer: Answer) {
        this.answer = answer
    }
}
