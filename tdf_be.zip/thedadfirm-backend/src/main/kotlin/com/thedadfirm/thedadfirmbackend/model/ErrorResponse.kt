package com.thedadfirm.thedadfirmbackend.model

data class ErrorResponse(
    val errorMessage: String,
    val errorType: String
)
data class NotFoundResponse(
    val errorMessage: String,
    val errorType: String = "NOT_FOUND"
)
data class ConflictResponse(
    val errorMessage: String,
    val errorType: String = "CONFLICT"
)

data class ValidationResponse(
    val errorMessages: List<String>,
    val errorType: String = "INVALID"
)

data class ClientErrorResponse(
    val errorMessage: String = "A client error occurred when making this request. Check your request and try again.",
    val errorType: String = "CLIENT_ERROR"
)
