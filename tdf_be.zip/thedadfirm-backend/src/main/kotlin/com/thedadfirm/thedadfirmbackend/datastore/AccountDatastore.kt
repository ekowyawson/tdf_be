package com.thedadfirm.thedadfirmbackend.datastore

import com.thedadfirm.thedadfirmbackend.datastore.entity.AccountEntity
import com.thedadfirm.thedadfirmbackend.datastore.jpa.AccountRepository
import com.thedadfirm.thedadfirmbackend.exceptions.ConflictException
import com.thedadfirm.thedadfirmbackend.model.Account
import com.thedadfirm.thedadfirmbackend.model.UserProvider
import org.springframework.stereotype.Repository

@Repository
class AccountDatastore(
    val accountRepository: AccountRepository
) {
    fun create(account: Account): Account {
        retrieveAccountByUserProvider(UserProvider(account.providerAccountId, account.provider))?.let {
            throw ConflictException("Account with requested providerAccountId and provider already exists")
        }
        return accountRepository.saveAndFlush(AccountEntity.from(account)).toAccount()
    }

    fun retrieveAccountByUserProvider(userProvider: UserProvider): Account? {
        val (providerAccountId, provider) = userProvider
        return accountRepository.findByProviderAccountIdAndProvider(providerAccountId, provider)?.toAccount()
    }
}
