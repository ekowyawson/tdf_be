package com.thedadfirm.thedadfirmbackend.model

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.databind.json.JsonMapper
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper
import com.fasterxml.jackson.module.kotlin.KotlinModule
import com.fasterxml.jackson.module.kotlin.readValue
import com.thedadfirm.thedadfirmbackend.exceptions.DeserializationException
import java.io.File
import java.io.IOException

@JsonInclude(JsonInclude.Include.NON_EMPTY)
data class Questionnaire(
    val name: String,
    val questions: List<Question>,
    val subQuestionnaires: List<Questionnaire> = listOf(),
    var isComplete: Boolean = false,
    var failed: Boolean = false
) {
    companion object {
        fun fromYamlFile(file: File): Questionnaire {
            try {
                return YAMLMapper().apply {
                    this.registerModule(KotlinModule.Builder().build())
                }.readValue(file)
            } catch (e: IOException) {
                throw DeserializationException(file.name, Questionnaire::class, e)
            }
        }
    }

    fun clone(): Questionnaire {
        JsonMapper().apply {
            this.registerModule(KotlinModule.Builder().build())
        }.let { mapper ->
            mapper.writeValueAsString(this).let { string ->
                return mapper.readValue<Questionnaire>(string)
            }
        }
    }

    fun getSubQuestionnaire(name: String): Questionnaire? {
        return subQuestionnaires.find { it.name == name }
    }

    fun applyAnswers(answers: List<Answer>) {
        answers.forEach { answer: Answer ->
            questions.findByKey(answer.questionKey)?.applyAnswer(answer)
                ?: subQuestionnaires.forEach { questionnaire ->
                    questionnaire.applyAnswers(listOf(answer))
                }
        }
        isComplete = questions.isComplete()
    }
}

fun List<Question>.findByKey(key: String): Question? {
    return this.find { question -> question.get().key == key }
}

fun List<Question>.isComplete(): Boolean {
    return this.find { question -> question.get().answer == null }?.let {
        false
    } ?: true
}
