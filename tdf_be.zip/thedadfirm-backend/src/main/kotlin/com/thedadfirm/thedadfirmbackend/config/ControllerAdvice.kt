package com.thedadfirm.thedadfirmbackend.config

import com.thedadfirm.thedadfirmbackend.exceptions.ConflictException
import com.thedadfirm.thedadfirmbackend.exceptions.InternalErrorException
import com.thedadfirm.thedadfirmbackend.exceptions.InvalidOptionsException
import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.ClientErrorResponse
import com.thedadfirm.thedadfirmbackend.model.ConflictResponse
import com.thedadfirm.thedadfirmbackend.model.ErrorResponse
import com.thedadfirm.thedadfirmbackend.model.NotFoundResponse
import com.thedadfirm.thedadfirmbackend.model.ValidationResponse
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.http.converter.HttpMessageNotReadableException
import org.springframework.web.bind.MethodArgumentNotValidException
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestControllerAdvice
import org.springframework.web.client.HttpClientErrorException

@RestControllerAdvice
class ControllerAdvice {

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NotFoundException::class)
    fun handleNotFoundException(exception: NotFoundException): ResponseEntity<NotFoundResponse> {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
            NotFoundResponse(exception.message)
        )
    }

    @ResponseStatus(HttpStatus.CONFLICT)
    @ExceptionHandler(ConflictException::class)
    fun handleConflictException(exception: ConflictException): ResponseEntity<ConflictResponse> {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(
            ConflictResponse(exception.message)
        )
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(InternalErrorException::class)
    fun handleInternalError(exception: InternalErrorException): ResponseEntity<ErrorResponse> {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
            ErrorResponse(exception.message, exception.errorType)
        )
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMessageNotReadableException::class)
    fun handleNotReadable(exception: HttpMessageNotReadableException): ResponseEntity<ErrorResponse> {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
            exception.message?.let { exceptionMessage ->
                ErrorResponse(exceptionMessage, "BAD_REQUEST")
            } ?: ErrorResponse("Http message is not readable", "BAD_REQUEST")
        )
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException::class)
    fun handleValidation(exception: MethodArgumentNotValidException): ResponseEntity<ValidationResponse> {
        val validationErrors = exception.bindingResult.allErrors.map { objectError -> objectError.defaultMessage ?: "Invalid ${objectError.objectName}" }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
            ValidationResponse(validationErrors)
        )
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpClientErrorException::class)
    fun handleHttpClientError(exception: HttpClientErrorException): ResponseEntity<ClientErrorResponse> {
        return ResponseEntity.status(400).body(
            exception.message?.let { exceptionMessage ->
                ClientErrorResponse(exceptionMessage)
            } ?: ClientErrorResponse()
        )
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(InvalidOptionsException::class)
    fun handleInvalidOptions(exception: InvalidOptionsException): ResponseEntity<ClientErrorResponse> {
        return ResponseEntity.status(400).body(
            exception.message?.let { message -> ClientErrorResponse(message) }
                ?: ClientErrorResponse()
        )
    }
}
