package com.thedadfirm.thedadfirmbackend.datastore.entity

import com.thedadfirm.thedadfirmbackend.model.User
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table
import org.hibernate.Hibernate
import java.time.LocalDate
import java.util.UUID

@Entity
@Table(name = "user_table")
data class UserEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(nullable = false, updatable = false)
    var userId: UUID? = null,
    @Column(name = "email", updatable = true, nullable = false, unique = true)
    val email: String,
    @Column(name = "name", updatable = true, nullable = true)
    val name: String?,
    @Column(updatable = true, nullable = true)
    val emailVerified: LocalDate?,
    @Column(updatable = true, nullable = false)
    val agreedToTerms: Boolean,
    @Column(updatable = true, nullable = false)
    val qualified: Boolean
) {
    companion object {
        fun from(user: User): UserEntity {
            user.id?.let {
                return UserEntity(
                    userId = user.id,
                    email = user.email,
                    name = user.name,
                    emailVerified = user.emailVerified,
                    agreedToTerms = user.agreedToTerms,
                    qualified = user.qualified
                )
            } ?: return UserEntity(
                email = user.email,
                name = user.name,
                emailVerified = user.emailVerified,
                agreedToTerms = user.agreedToTerms,
                qualified = user.qualified
            )
        }
    }

    fun toUser(): User {
        return User(
            id = userId,
            email = email,
            name = name,
            emailVerified = emailVerified,
            agreedToTerms = agreedToTerms,
            qualified = qualified
        )
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || Hibernate.getClass(this) != Hibernate.getClass(other)) return false
        other as UserEntity

        return userId != null && userId == other.userId
    }

    override fun hashCode(): Int = javaClass.hashCode()

    @Override
    override fun toString(): String {
        return this::class.simpleName + "(userId = $userId )"
    }
}
