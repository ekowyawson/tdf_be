package com.thedadfirm.thedadfirmbackend.service

import com.thedadfirm.thedadfirmbackend.datastore.UserDatastore
import com.thedadfirm.thedadfirmbackend.model.UpdateUserRequest
import com.thedadfirm.thedadfirmbackend.model.User
import org.springframework.http.HttpStatusCode
import org.springframework.stereotype.Service
import org.springframework.web.client.HttpClientErrorException
import java.util.UUID

@Service
class UserService(
    val userDatastore: UserDatastore
) {
    fun createUser(user: User): User {
        return userDatastore.createUser(user)
    }

    fun getUserById(id: UUID): User {
        return userDatastore.retrieveUserByUUID(id)
    }

    fun getUserByEmail(email: String): User {
        return userDatastore.retrieveUserByEmail(email)
    }

    fun updateUser(id: UUID, updateUserRequest: UpdateUserRequest): User {
        if (updateUserRequest.allValuesAreNull()) {
            throw HttpClientErrorException(HttpStatusCode.valueOf(400), "All updatable values are null, no update processed")
        }
        return userDatastore.updateUser(id, updateUserRequest)
    }
}
