package com.thedadfirm.thedadfirmbackend.service

import com.thedadfirm.thedadfirmbackend.exceptions.DeserializationException
import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.Questionnaire
import mu.KotlinLogging
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service
import java.io.File

@Service
class QuestionnaireService(
    @Value("\${questionnaires.location}")
    private val questionnairesDirectory: String,
    private val questionnaires: MutableList<Questionnaire>
) {
    private val logger = KotlinLogging.logger {}

    init {
        File(questionnairesDirectory).walk().forEach { file ->
            addQuestionnaire(file)
        }
    }

    fun getQuestionnaire(name: String): Questionnaire? {
        return questionnaires.find { it.name == name }?.clone()
    }

    fun getSubQuestionnaire(name: String, rootQuestionnaireName: String): Questionnaire? {
        getQuestionnaire(rootQuestionnaireName)?.let { questionnaire ->
            return questionnaire.getSubQuestionnaire(name)
        } ?: throw NotFoundException("No questionnaire with name $rootQuestionnaireName found.")
    }

    private fun addQuestionnaire(file: File) {
        if (file.extension == "yml") {
            logger.info { "Attempting to add questionnaire from ${file.name}" }
            try {
                Questionnaire.fromYamlFile(file).let { new ->
                    getQuestionnaire(new.name)?.let { existing ->
                        logger.warn { "Questionnaire with name ${existing.name} already exists. Questionnaire names must be unique. Ignoring ${file.name}" }
                        return
                    } ?: questionnaires.add(new)
                }
                logger.info { "Added questionnaire from ${file.name}" }
            } catch (e: DeserializationException) {
                logger.error(e.message, e.cause)
            }
        }
    }
}
