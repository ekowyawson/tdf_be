package com.thedadfirm.thedadfirmbackend.datastore

import com.thedadfirm.thedadfirmbackend.datastore.entity.SessionEntity
import com.thedadfirm.thedadfirmbackend.datastore.jpa.SessionRepository
import com.thedadfirm.thedadfirmbackend.exceptions.DataException
import com.thedadfirm.thedadfirmbackend.exceptions.InternalErrorException
import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.Session
import jakarta.transaction.Transactional
import org.springframework.stereotype.Repository
import java.time.LocalDate

@Repository
class SessionDatastore(
    val sessionRepository: SessionRepository
) {
    fun create(session: Session): Session {
        try {
            return sessionRepository.saveAndFlush(SessionEntity.from(session)).toSession()
        } catch (e: Exception) {
            throw InternalErrorException("Unexpected error occurred: ${e.message} <- ${e.cause}")
        }
    }

    fun findSession(sessionToken: String): Session {
        sessionRepository.findBySessionToken(sessionToken)?.let { sessionEntity ->
            return sessionEntity.toSession()
        } ?: throw NotFoundException("Session not found: $sessionToken")
    }

    @Transactional
    fun updateSession(sessionToken: String, expires: LocalDate): Session {
        sessionRepository.updateExpires(sessionToken, expires)
        findSession(sessionToken).let { session ->
            if (expires == session.expires) {
                return session
            }
            throw DataException("Failed to update Session $sessionToken: $expires != ${session.expires}", "UNKNOWN")
        }
    }
}
