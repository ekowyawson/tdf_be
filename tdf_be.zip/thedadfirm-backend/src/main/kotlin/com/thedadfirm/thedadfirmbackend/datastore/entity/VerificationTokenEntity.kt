package com.thedadfirm.thedadfirmbackend.datastore.entity

import com.thedadfirm.thedadfirmbackend.model.VerificationToken
import jakarta.persistence.Column
import jakarta.persistence.Embeddable
import jakarta.persistence.EmbeddedId
import jakarta.persistence.Entity
import jakarta.persistence.Table
import java.io.Serializable
import java.time.LocalDate

@Embeddable
data class VerificationId(
    @Column(name = "identifier", nullable = false, updatable = false)
    val identifier: String,
    @Column(name = "token", nullable = false, updatable = false)
    val token: String
) : Serializable

@Entity
@Table(name = "verify_table")
data class VerificationTokenEntity(
    // Refuses to be unique, no good resources online to assist. Fixing with code, instead of DB constraint
    @EmbeddedId
    val verificationId: VerificationId,
    @Column(nullable = false, updatable = false)
    val expires: LocalDate
) {
    companion object {
        fun from(verificationToken: VerificationToken): VerificationTokenEntity {
            verificationToken.expires?.let { expires ->
                return VerificationTokenEntity(
                    verificationId = verificationToken.getId(),
                    expires = expires
                )
            } ?: throw NullPointerException("expires can not be null")
        }
    }

    fun toVerificationToken(): VerificationToken {
        return VerificationToken(
            identifier = this.verificationId.identifier,
            token = this.verificationId.token,
            expires = this.expires
        )
    }
}
