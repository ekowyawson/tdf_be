package com.thedadfirm.thedadfirmbackend.exceptions

import java.io.IOException
import kotlin.reflect.KClass

class DeserializationException(fileName: String, type: KClass<*>, cause: Throwable) :
    IOException(deserializationMessage(fileName, type), cause)
fun deserializationMessage(fileName: String, type: KClass<*>) =
    "$fileName could not be deserialized to ${type.simpleName}"
