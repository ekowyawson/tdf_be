package com.thedadfirm.thedadfirmbackend.datastore.jpa

import com.thedadfirm.thedadfirmbackend.datastore.entity.VerificationId
import com.thedadfirm.thedadfirmbackend.datastore.entity.VerificationTokenEntity
import org.springframework.data.jpa.repository.JpaRepository

interface VerifyRepository : JpaRepository<VerificationTokenEntity, VerificationId> {

    fun findByVerificationIdIdentifier(identifier: String): VerificationTokenEntity?
}
