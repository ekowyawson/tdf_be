package com.thedadfirm.thedadfirmbackend.datastore.entity

import com.thedadfirm.thedadfirmbackend.model.Account
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.util.UUID

@Entity
@Table(name = "account_table")
data class AccountEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(nullable = false, updatable = false)
    var accountId: UUID? = null,
    @Column(nullable = false, updatable = false)
    val userId: UUID,
    @Column(nullable = false, updatable = false)
    val provider: String,
    @Column(name = "provider_account_id", nullable = false, updatable = false)
    val providerAccountId: String,
    @Column(name = "refresh_token", nullable = false, updatable = true)
    val refreshToken: String,
    @Column(name = "access_token", nullable = false, updatable = false)
    val accessToken: String,
    @Column(name = "expires_at", nullable = false, updatable = true)
    val expiresAt: Int,
    @Column(name = "toke_type", nullable = false, updatable = false)
    val tokenType: String,
    @Column(nullable = false, updatable = false)
    val scope: String,
    @Column(name = "id_token", nullable = false, updatable = false)
    val idToken: String,
    @Column(name = "session_state", nullable = false, updatable = true)
    val sessionState: String
) {
    fun toAccount(): Account {
        return Account(
            id = accountId,
            userId = userId,
            provider = provider,
            providerAccountId = providerAccountId,
            refreshToken = refreshToken,
            accessToken = accessToken,
            expiresAt = expiresAt,
            tokenType = tokenType,
            scope = scope,
            idToken = idToken,
            sessionState = sessionState
        )
    }

    companion object {
        fun from(account: Account): AccountEntity {
            return AccountEntity(
                userId = account.userId,
                provider = account.provider,
                providerAccountId = account.providerAccountId,
                refreshToken = account.refreshToken,
                accessToken = account.accessToken,
                expiresAt = account.expiresAt,
                tokenType = account.tokenType,
                scope = account.scope,
                idToken = account.idToken,
                sessionState = account.sessionState
            )
        }
    }
}
