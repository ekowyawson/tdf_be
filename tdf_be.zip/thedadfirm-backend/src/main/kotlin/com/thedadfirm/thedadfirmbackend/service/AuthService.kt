package com.thedadfirm.thedadfirmbackend.service

import com.thedadfirm.thedadfirmbackend.datastore.AuthRepositoryAdapter
import com.thedadfirm.thedadfirmbackend.model.Account
import com.thedadfirm.thedadfirmbackend.model.Session
import com.thedadfirm.thedadfirmbackend.model.UpdateSessionRequest
import com.thedadfirm.thedadfirmbackend.model.User
import com.thedadfirm.thedadfirmbackend.model.UserProvider
import com.thedadfirm.thedadfirmbackend.model.UserWithSession
import com.thedadfirm.thedadfirmbackend.model.VerificationToken
import org.springframework.http.HttpStatusCode
import org.springframework.stereotype.Service
import org.springframework.web.client.HttpClientErrorException

@Service
class AuthService(
    val authRepositoryAdapter: AuthRepositoryAdapter
) {
    fun createSession(session: Session): Session {
        return authRepositoryAdapter.createSession(session)
    }

    fun getSessionWithUser(sessionToken: String): UserWithSession {
        authRepositoryAdapter.getSessionAndUser(sessionToken).let { (session, user) ->
            return UserWithSession(user, session)
        }
    }

    fun updateSession(sessionToken: String, updateSessionRequest: UpdateSessionRequest): Session {
        updateSessionRequest.expires?.let { expires ->
            return authRepositoryAdapter.updateSession(sessionToken, expires)
        } ?: throw HttpClientErrorException(
            HttpStatusCode.valueOf(400),
            "All updatable values are null, no update processed"
        )
    }

    fun createVerifyToken(verificationToken: VerificationToken): VerificationToken {
        verificationToken.expires?.let {
            return authRepositoryAdapter.createVerificationToken(verificationToken)
        } ?: throw HttpClientErrorException(
            HttpStatusCode.valueOf(400),
            "expires can not be null"
        )
    }

    fun useVerifyToken(verificationToken: VerificationToken): VerificationToken {
        return authRepositoryAdapter.useVerificationToken(verificationToken)
    }

    fun linkAccount(account: Account): Account {
        return authRepositoryAdapter.linkAccount(account)
    }

    fun getUserByUserProvider(userProvider: UserProvider): User {
        return authRepositoryAdapter.getUserByAccount(userProvider)
    }
}
