package com.thedadfirm.thedadfirmbackend.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.thedadfirm.thedadfirmbackend.datastore.entity.VerificationId
import java.time.LocalDate

data class VerificationToken(
    val identifier: String,
    val token: String,
    val expires: LocalDate? = null
) {
    @JsonIgnore
    fun getId(): VerificationId {
        return VerificationId(
            identifier = this.identifier,
            token = this.token
        )
    }
}
