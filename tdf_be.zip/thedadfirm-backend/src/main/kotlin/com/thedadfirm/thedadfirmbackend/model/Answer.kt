package com.thedadfirm.thedadfirmbackend.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonInclude.Include

data class Answer(
    @JsonIgnore
    val questionKey: String,
    val value: String
)

@JsonInclude(Include.NON_NULL)
data class AnswerWithQuestionnaire(
    val questionKey: String,
    val value: String,
    val questionnaire: String,
    val subQuestionnaireOf: String? = null
)
