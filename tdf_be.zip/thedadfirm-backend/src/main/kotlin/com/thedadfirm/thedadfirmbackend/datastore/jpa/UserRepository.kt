package com.thedadfirm.thedadfirmbackend.datastore.jpa

import com.thedadfirm.thedadfirmbackend.datastore.entity.UserEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.transaction.annotation.Transactional
import java.time.LocalDate
import java.util.UUID

interface UserRepository : JpaRepository<UserEntity, UUID> {
    fun findByEmail(email: String): UserEntity?

    @Transactional
    @Modifying
    @Query("update UserEntity u set u.email = ?1 where u.userId = ?2")
    fun updateEmailByUserId(email: String, userId: UUID): Int

    @Transactional
    @Modifying
    @Query("update UserEntity u set u.name = ?1 where u.userId = ?2")
    fun updateNameByUserId(name: String, userId: UUID): Int

    @Transactional
    @Modifying
    @Query("update UserEntity u set u.emailVerified = ?1 where u.userId = ?2")
    fun updateEmailVerifiedByUserId(emailVerified: LocalDate, uuid: UUID): Int

    @Transactional
    @Modifying
    @Query("update UserEntity u set u.agreedToTerms = ?1 where u.userId = ?2")
    fun updateAgreedToTermsByUserId(agreedToTerms: Boolean, uuid: UUID): Int

    @Transactional
    @Modifying
    @Query("update UserEntity u set u.qualified = ?1 where u.userId = ?2")
    fun updateQualifiedByUserId(qualified: Boolean, uuid: UUID): Int
}
