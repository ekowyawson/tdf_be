package com.thedadfirm.thedadfirmbackend.exceptions

open class InvalidQuestionException(override val message: String?) : Exception()
class InvalidOptionsException(override val message: String?, invalidOptions: List<String>, validOptions: List<String>) : InvalidQuestionException(message)
