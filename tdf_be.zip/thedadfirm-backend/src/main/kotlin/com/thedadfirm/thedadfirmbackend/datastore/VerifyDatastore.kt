package com.thedadfirm.thedadfirmbackend.datastore

import com.thedadfirm.thedadfirmbackend.datastore.entity.VerificationTokenEntity
import com.thedadfirm.thedadfirmbackend.datastore.jpa.VerifyRepository
import com.thedadfirm.thedadfirmbackend.exceptions.InternalErrorException
import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.VerificationToken
import jakarta.transaction.Transactional
import org.springframework.data.repository.findByIdOrNull
import org.springframework.stereotype.Repository

@Repository
class VerifyDatastore(
    val verifyRepository: VerifyRepository
) {
    fun create(verificationToken: VerificationToken): VerificationToken {
        verifyRepository.findByVerificationIdIdentifier(verificationToken.identifier)?.let { verifyEntity ->
            if (verificationToken.token == verifyEntity.verificationId.token) {
                return verifyEntity.toVerificationToken()
            }
            verifyRepository.delete(verifyEntity)
        }
        try {
            return verifyRepository.saveAndFlush(
                VerificationTokenEntity.from(verificationToken)
            ).toVerificationToken()
        } catch (e: Exception) {
            throw InternalErrorException("Unexpected error occurred: ${e.message} <- ${e.cause}")
        }
    }

    @Transactional
    fun use(verificationToken: VerificationToken): VerificationToken {
        verifyRepository.findByIdOrNull(verificationToken.getId())?.let { verifyEntity ->
            verifyRepository.delete(verifyEntity)
            return verifyEntity.toVerificationToken()
        } ?: throw NotFoundException("Verify token not found: ${verificationToken.identifier}")
    }
}
