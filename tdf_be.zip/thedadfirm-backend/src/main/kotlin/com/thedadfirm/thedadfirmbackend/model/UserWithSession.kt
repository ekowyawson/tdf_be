package com.thedadfirm.thedadfirmbackend.model

data class UserWithSession(
    val user: User,
    val session: Session
)
