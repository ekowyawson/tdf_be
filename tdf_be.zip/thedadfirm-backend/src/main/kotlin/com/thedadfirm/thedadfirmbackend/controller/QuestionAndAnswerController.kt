package com.thedadfirm.thedadfirmbackend.controller

import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.AnswerWithQuestionnaire
import com.thedadfirm.thedadfirmbackend.model.Questionnaire
import com.thedadfirm.thedadfirmbackend.service.AnswerService
import com.thedadfirm.thedadfirmbackend.service.QuestionnaireService
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController
import java.util.UUID

@RestController
@RequestMapping("/questions")
// Need to add @CrossOrigin(origins = ["http://localhost:3000"]) when running locally
@CrossOrigin(origins = ["http://localhost:3000"])
class QuestionAndAnswerController(
    val questionnaireService: QuestionnaireService,
    val answerService: AnswerService
) {
    @GetMapping("/{name}")
    fun get(
        @PathVariable name: String
    ): Questionnaire {
        return questionnaireService.getQuestionnaire(name)
            ?: throw NotFoundException("No questionnaire $name found.")
    }

    @PutMapping("/{id}/answer")
    @ResponseStatus(HttpStatus.CREATED)
    fun answerQuestion(
        @PathVariable id: UUID,
        @RequestBody answerRequest: AnswerWithQuestionnaire
    ): AnswerWithQuestionnaire {
        return answerService.answer(answerRequest, id)
    }

    @PutMapping("/by-email/{email}/answer")
    @ResponseStatus(HttpStatus.CREATED)
    fun answerQuestionByEmail(
        @PathVariable email: String,
        @RequestBody answerRequest: AnswerWithQuestionnaire
    ): AnswerWithQuestionnaire {
        return answerService.answer(answerRequest, email = email)
    }

    @GetMapping("/{name}/{id}")
    fun getQuestionnaireWithAnswers(
        @PathVariable id: UUID,
        @PathVariable name: String
    ): Questionnaire {
        questionnaireService.getQuestionnaire(name)?.let { questionnaire ->
            questionnaire.applyAnswers(answerService.getAnswers(questionnaire.name, id))
            return questionnaire
        } ?: throw NotFoundException("No questionnaire $name found.")
    }

    @GetMapping("/{name}/by-email/{email}")
    fun getQuestionnaireWithAnswersByEmail(
        @PathVariable name: String,
        @PathVariable email: String
    ): Questionnaire {
        questionnaireService.getQuestionnaire(name)?.let { questionnaire ->
            questionnaire.applyAnswers(answerService.getAnswers(questionnaire.name, email = email))
            return questionnaire
        } ?: throw NotFoundException("No questionnaire $name found.")
    }
}
