package com.thedadfirm.thedadfirmbackend.datastore.entity

import com.thedadfirm.thedadfirmbackend.model.Session
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.time.LocalDate
import java.util.UUID

@Entity
@Table(name = "session_table")
data class SessionEntity(
    @Id
    @Column(nullable = false, updatable = false, unique = true)
    val sessionToken: String,
    @Column(nullable = false, updatable = true)
    var expires: LocalDate,
    @Column(nullable = false, updatable = false)
    val userId: UUID
) {
    companion object {
        fun from(session: Session): SessionEntity {
            return SessionEntity(
                expires = session.expires,
                sessionToken = session.sessionToken,
                userId = session.userId
            )
        }
    }

    fun toSession(): Session {
        return Session(
            expires = this.expires,
            sessionToken = this.sessionToken,
            userId = this.userId
        )
    }
}
