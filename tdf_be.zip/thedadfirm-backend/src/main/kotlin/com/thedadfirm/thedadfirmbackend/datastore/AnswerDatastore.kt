package com.thedadfirm.thedadfirmbackend.datastore

import com.thedadfirm.thedadfirmbackend.datastore.entity.AnswerEntity
import com.thedadfirm.thedadfirmbackend.datastore.jpa.AnswerRepository
import com.thedadfirm.thedadfirmbackend.model.Answer
import com.thedadfirm.thedadfirmbackend.model.AnswerWithQuestionnaire
import org.springframework.stereotype.Repository
import java.util.UUID

@Repository
class AnswerDatastore(
    val answerRepository: AnswerRepository
) {
    fun answerQuestion(userId: UUID, answerRequest: AnswerWithQuestionnaire): AnswerWithQuestionnaire {
        return answerRepository.saveAndFlush(AnswerEntity.from(userId, answerRequest)).toAnswerWithQuestionnaire()
    }

    fun getAnswersFor(userId: UUID, questionnaireName: String): List<Answer> {
        return answerRepository.findByQuestionnaireAndUserId(questionnaireName, userId).toAnswerList()
    }
}

private fun List<AnswerEntity>.toAnswerList(): List<Answer> {
    return this.map { answerEntity -> answerEntity.toAnswer() }
}
