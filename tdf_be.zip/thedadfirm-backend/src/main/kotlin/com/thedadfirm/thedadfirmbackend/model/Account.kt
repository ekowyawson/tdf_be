package com.thedadfirm.thedadfirmbackend.model

import java.util.UUID

data class Account(
    var id: UUID? = null,
    val userId: UUID,
    val provider: String,
    val providerAccountId: String,
    val refreshToken: String,
    val accessToken: String,
    val expiresAt: Int,
    val tokenType: String,
    val scope: String,
    val idToken: String,
    var sessionState: String
)

data class UserProvider(
    val providerAccountId: String,
    val provider: String
)
