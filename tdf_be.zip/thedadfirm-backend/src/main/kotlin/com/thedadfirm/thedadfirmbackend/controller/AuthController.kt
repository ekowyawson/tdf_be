package com.thedadfirm.thedadfirmbackend.controller

import com.thedadfirm.thedadfirmbackend.model.Account
import com.thedadfirm.thedadfirmbackend.model.Session
import com.thedadfirm.thedadfirmbackend.model.UpdateSessionRequest
import com.thedadfirm.thedadfirmbackend.model.UserWithSession
import com.thedadfirm.thedadfirmbackend.model.VerificationToken
import com.thedadfirm.thedadfirmbackend.service.AuthService
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PatchMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/auth")
// Need to add @CrossOrigin(origins = ["http://localhost:3000"]) when running locally
@CrossOrigin(origins = ["http://localhost:3000"])
class AuthController(
    val authService: AuthService
) {

    @PostMapping("/session/create")
    @ResponseStatus(HttpStatus.CREATED)
    fun createSession(
        @RequestBody createSessionRequest: Session
    ): Session {
        return authService.createSession(createSessionRequest)
    }

    @GetMapping("/session/{sessionToken}")
    fun getSessionWithUser(
        @PathVariable sessionToken: String
    ): UserWithSession {
        return authService.getSessionWithUser(sessionToken)
    }

    @PatchMapping("/session/{sessionToken}")
    fun updateSession(
        @PathVariable sessionToken: String,
        @RequestBody updateSessionRequest: UpdateSessionRequest
    ): Session {
        return authService.updateSession(sessionToken, updateSessionRequest)
    }

    @PostMapping("/verify/create")
    @ResponseStatus(HttpStatus.CREATED)
    fun createVerificationToken(
        @RequestBody verificationToken: VerificationToken
    ): VerificationToken {
        return authService.createVerifyToken(verificationToken)
    }

    @PostMapping("/verify/use")
    fun useVerificationToken(
        @RequestBody verificationToken: VerificationToken
    ): VerificationToken {
        return authService.useVerifyToken(verificationToken)
    }

    @PostMapping("/account/link")
    fun linkAccount(
        @RequestBody account: Account
    ): Account {
        return authService.linkAccount(account)
    }
}
