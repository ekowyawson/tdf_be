package com.thedadfirm.thedadfirmbackend.datastore

import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.Account
import com.thedadfirm.thedadfirmbackend.model.Session
import com.thedadfirm.thedadfirmbackend.model.User
import com.thedadfirm.thedadfirmbackend.model.UserProvider
import com.thedadfirm.thedadfirmbackend.model.VerificationToken
import org.springframework.stereotype.Repository
import java.time.LocalDate

@Repository
class AuthRepositoryAdapter(
    val userDatastore: UserDatastore,
    val verifyDatastore: VerifyDatastore,
    val accountDatastore: AccountDatastore,
    val sessionDatastore: SessionDatastore

) {
    fun linkAccount(account: Account): Account {
        userDatastore.retrieveUserByUUID(account.userId).let {
            return accountDatastore.create(account)
        }
    }

    fun getUserByAccount(provider: UserProvider): User {
        accountDatastore.retrieveAccountByUserProvider(provider)?.let { account ->
            return userDatastore.retrieveUserByUUID(account.userId)
        } ?: throw NotFoundException("User not found by account: $provider")
    }

    fun createSession(session: Session): Session {
        return sessionDatastore.create(session)
    }

    fun getSessionAndUser(sessionToken: String): Pair<Session, User> {
        sessionDatastore.findSession(sessionToken).let { session ->
            userDatastore.retrieveUserByUUID(session.userId).let { user ->
                return Pair(session, user)
            }
        }
    }

    fun updateSession(sessionToken: String, expires: LocalDate): Session {
        return sessionDatastore.updateSession(sessionToken, expires)
    }

    fun createVerificationToken(verificationToken: VerificationToken): VerificationToken {
        return verifyDatastore.create(verificationToken)
    }

    fun useVerificationToken(verificationToken: VerificationToken): VerificationToken {
        return verifyDatastore.use(verificationToken)
    }
}
