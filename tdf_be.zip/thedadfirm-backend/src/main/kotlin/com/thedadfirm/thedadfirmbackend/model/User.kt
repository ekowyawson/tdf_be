package com.thedadfirm.thedadfirmbackend.model

import com.fasterxml.jackson.annotation.JsonFormat
import com.fasterxml.jackson.annotation.JsonInclude
import com.thedadfirm.thedadfirmbackend.util.NullOrNotBlank
import jakarta.validation.constraints.Email
import jakarta.validation.constraints.NotEmpty
import java.time.LocalDate
import java.util.UUID

@JsonInclude(JsonInclude.Include.NON_NULL)
data class User(
    @field:NotEmpty(message = "Email is required")
    @field:Email(message = "Email is not formatted properly")
    val email: String,
    @field:NullOrNotBlank(message = "Name can not be blank, if not null.")
    val name: String? = null,
    val id: UUID? = null,
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    val emailVerified: LocalDate? = null,
    val agreedToTerms: Boolean = false,
    val qualified: Boolean = false
)

data class UpdateUserRequest(
    val email: String? = null,
    val name: String? = null,
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    val emailVerified: LocalDate? = null,
    val agreedToTerms: Boolean? = null,
    val qualified: Boolean? = null
) {
    fun allValuesAreNull(): Boolean {
        email?.let {
            return false
        }
        name?.let {
            return false
        }
        emailVerified?.let {
            return false
        }
        agreedToTerms?.let {
            return false
        }
        qualified?.let {
            return false
        }
        return true
    }
    fun updateWasSuccess(user: User): Boolean {
        email?.let { requestEmail ->
            if (user.email != requestEmail) {
                return false
            }
        }
        name?.let { requestName ->
            if (user.name != requestName) {
                return false
            }
        }
        emailVerified?.let { requestEmailVerified ->
            if (user.emailVerified != requestEmailVerified) {
                return false
            }
        }
        return true
    }
}

data class CreateUserResponse(
    val userId: UUID
)
