package com.thedadfirm.thedadfirmbackend.controller

import com.thedadfirm.thedadfirmbackend.datastore.DangerousRepositoryAdapter
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/manage")
@ConditionalOnExpression("\${dangerous-controller:false}")
class TableManagementController(
    val dangerousRepositoryAdapter: DangerousRepositoryAdapter
) {
    @DeleteMapping("/user")
    fun deleteAllUsers() {
        return dangerousRepositoryAdapter.deleteAllUsers()
    }
//    TODO: Add individual delete methods for all repos
//    @DeleteMapping("/answer")
//
//    @DeleteMapping("/session")
//
//    @DeleteMapping("/verify")
//
//    @DeleteMapping("/account")

    @DeleteMapping("/all")
    fun clearDb() {
        return dangerousRepositoryAdapter.wipe()
    }
}
