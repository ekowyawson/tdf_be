package com.thedadfirm.thedadfirmbackend.exceptions

open class DataException(override val message: String, open val errorType: String) : Exception(message)

class NotFoundException(override val message: String, override val errorType: String = "NOT_FOUND") :
    DataException(message, errorType)

class ConflictException(override val message: String, override val errorType: String = "CONFLICT") :
    DataException(message, errorType)

class InternalErrorException(override val message: String, override val errorType: String = "SERVER_ERROR") :
    DataException(message, errorType)

class ClientErrorException(override val message: String, override val errorType: String = "CLIENT_ERROR") :
    DataException(message, errorType)
