package com.thedadfirm.thedadfirmbackend.datastore.entity

import com.thedadfirm.thedadfirmbackend.model.Answer
import com.thedadfirm.thedadfirmbackend.model.AnswerWithQuestionnaire
import jakarta.persistence.Column
import jakarta.persistence.Embeddable
import jakarta.persistence.Entity
import jakarta.persistence.Id
import jakarta.persistence.IdClass
import jakarta.persistence.Table
import org.hibernate.Hibernate
import java.io.Serializable
import java.util.UUID

@Embeddable
open class AnswerId(
    val key: String,
    val userId: UUID
) : Serializable

@Entity
@IdClass(AnswerId::class)
@Table(name = "answer_table")
data class AnswerEntity(
    @Id
    @Column(nullable = false)
    val key: String,
    @Id
    @Column(nullable = false, updatable = false)
    val userId: UUID,
    @Column(updatable = true, nullable = false)
    val value: String,
    @Column(updatable = true, nullable = false)
    val questionnaire: String,
    @Column(updatable = true, nullable = true)
    val subQuestionnaire: String? = null
) {
    companion object {
        fun from(userId: UUID, answerWithQuestionnaire: AnswerWithQuestionnaire): AnswerEntity {
            return AnswerEntity(
                key = answerWithQuestionnaire.questionKey,
                userId = userId,
                value = answerWithQuestionnaire.value,
                questionnaire = answerWithQuestionnaire.questionnaire,
                subQuestionnaire = answerWithQuestionnaire.subQuestionnaireOf
            )
        }
    }
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || Hibernate.getClass(this) != Hibernate.getClass(other)) return false
        other as AnswerEntity

        return key == other.key
    }

    override fun hashCode(): Int = javaClass.hashCode()

    @Override
    override fun toString(): String {
        return this::class.simpleName + "(key = $key )"
    }

    fun toAnswerWithQuestionnaire(): AnswerWithQuestionnaire {
        return AnswerWithQuestionnaire(
            questionKey = key,
            value = value,
            questionnaire = questionnaire,
            subQuestionnaireOf = subQuestionnaire
        )
    }

    fun toAnswer(): Answer {
        return Answer(questionKey = key, value = value)
    }
}
