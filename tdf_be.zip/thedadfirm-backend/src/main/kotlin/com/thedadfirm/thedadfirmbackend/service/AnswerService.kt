package com.thedadfirm.thedadfirmbackend.service

import com.thedadfirm.thedadfirmbackend.datastore.AnswerDatastore
import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.Answer
import com.thedadfirm.thedadfirmbackend.model.AnswerWithQuestionnaire
import com.thedadfirm.thedadfirmbackend.model.Question
import com.thedadfirm.thedadfirmbackend.model.findByKey
import org.springframework.stereotype.Service
import java.util.UUID

@Service
class AnswerService(
    val questionnaireService: QuestionnaireService,
    val userService: UserService,
    val answerDatastore: AnswerDatastore
) {
    fun answer(
        answerRequest: AnswerWithQuestionnaire,
        userId: UUID? = null,
        email: String? = null
    ): AnswerWithQuestionnaire {
        val retrievedUserId = retrieveAndValidate(userId, email)
        answerRequest.subQuestionnaireOf?.let { subQuestionnaireOf ->
            questionnaireService.getSubQuestionnaire(answerRequest.questionnaire, subQuestionnaireOf)
                ?.let { foundQuestionnaire ->
                    return foundQuestionnaire.questions.findByKeyAndAnswer(retrievedUserId, answerRequest)
                } ?: throw NotFoundException("No questionnaire with name ${answerRequest.questionnaire} found.")
        }
        questionnaireService.getQuestionnaire(answerRequest.questionnaire)?.let { questionnaire ->
            return questionnaire.questions.findByKeyAndAnswer(retrievedUserId, answerRequest)
        } ?: throw NotFoundException("No questionnaire with name ${answerRequest.questionnaire} found.")
    }

    private fun List<Question>.findByKeyAndAnswer(
        userId: UUID,
        answerRequest: AnswerWithQuestionnaire
    ): AnswerWithQuestionnaire {
        this.findByKey(answerRequest.questionKey)?.applyAnswer(Answer(answerRequest.questionKey, answerRequest.value))
            ?: throw NotFoundException("No question with key ${answerRequest.questionKey} exists in ${answerRequest.questionnaire}")
        return answerDatastore.answerQuestion(userId, answerRequest)
    }

    fun getAnswers(questionnaireName: String, userId: UUID? = null, email: String? = null): List<Answer> {
        val retrievedUserId = retrieveAndValidate(userId, email)
        questionnaireService.getQuestionnaire(questionnaireName)?.let { questionnaire ->
            val mutableAnswerList = mutableListOf<Answer>()
            mutableAnswerList.addAll(answerDatastore.getAnswersFor(retrievedUserId, questionnaireName))
            questionnaire.subQuestionnaires.forEach { subQuestionnaire ->
                mutableAnswerList.addAll(answerDatastore.getAnswersFor(retrievedUserId, subQuestionnaire.name))
            }
            return mutableAnswerList
        } ?: throw NotFoundException("No questionnaire with name $questionnaireName found.")
    }

    private fun retrieveAndValidate(userId: UUID?, email: String?) = userId?.let {
        return@let userService.getUserById(userId).id
    } ?: email?.let {
        return@let userService.getUserByEmail(email).id
    } ?: throw NullPointerException("Both userId and email are null. One must be provided.")
}
