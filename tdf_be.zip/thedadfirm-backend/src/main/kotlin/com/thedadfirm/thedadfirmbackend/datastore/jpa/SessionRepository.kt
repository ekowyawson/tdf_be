package com.thedadfirm.thedadfirmbackend.datastore.jpa

import com.thedadfirm.thedadfirmbackend.datastore.entity.SessionEntity
import jakarta.transaction.Transactional
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import java.time.LocalDate
import java.util.UUID

interface SessionRepository : JpaRepository<SessionEntity, UUID> {
    fun findBySessionToken(sessionToken: String): SessionEntity?

    @Transactional
    @Modifying
    @Query("update SessionEntity s set s.expires = ?2 where s.sessionToken = ?1")
    fun updateExpires(sessionToken: String, expires: LocalDate): Int
}
