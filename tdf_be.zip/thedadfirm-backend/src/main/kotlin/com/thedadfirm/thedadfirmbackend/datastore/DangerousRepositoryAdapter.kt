package com.thedadfirm.thedadfirmbackend.datastore

import com.thedadfirm.thedadfirmbackend.datastore.jpa.AccountRepository
import com.thedadfirm.thedadfirmbackend.datastore.jpa.AnswerRepository
import com.thedadfirm.thedadfirmbackend.datastore.jpa.SessionRepository
import com.thedadfirm.thedadfirmbackend.datastore.jpa.UserRepository
import com.thedadfirm.thedadfirmbackend.datastore.jpa.VerifyRepository
import jakarta.transaction.Transactional
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression
import org.springframework.stereotype.Repository

@Repository
@ConditionalOnExpression("\${dangerous-controller:false}")
class DangerousRepositoryAdapter(
    val accountRepository: AccountRepository,
    val userRepository: UserRepository,
    val sessionRepository: SessionRepository,
    val verifyRepository: VerifyRepository,
    val answerRepository: AnswerRepository
) {

    @Transactional
    fun wipe() {
        listOf(
            accountRepository,
            userRepository,
            sessionRepository,
            verifyRepository,
            answerRepository
        ).forEach { jpaRepository ->
            jpaRepository.deleteAll()
            jpaRepository.flush()
        }
    }

    fun deleteAllUsers() {
        userRepository.deleteAll()
        userRepository.flush()
    }
}
