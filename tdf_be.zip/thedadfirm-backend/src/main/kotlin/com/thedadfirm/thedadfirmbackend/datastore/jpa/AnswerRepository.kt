package com.thedadfirm.thedadfirmbackend.datastore.jpa

import com.thedadfirm.thedadfirmbackend.datastore.entity.AnswerEntity
import com.thedadfirm.thedadfirmbackend.datastore.entity.AnswerId
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import java.util.UUID

interface AnswerRepository : JpaRepository<AnswerEntity, AnswerId> {

    @Query("select a from AnswerEntity a where a.questionnaire = ?1 and a.userId = ?2")
    fun findByQuestionnaireAndUserId(questionnaire: String, userId: UUID): List<AnswerEntity>
}
