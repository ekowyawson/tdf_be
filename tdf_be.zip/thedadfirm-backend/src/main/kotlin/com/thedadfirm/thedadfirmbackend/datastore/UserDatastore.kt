package com.thedadfirm.thedadfirmbackend.datastore

import com.thedadfirm.thedadfirmbackend.datastore.entity.UserEntity
import com.thedadfirm.thedadfirmbackend.datastore.jpa.UserRepository
import com.thedadfirm.thedadfirmbackend.exceptions.ConflictException
import com.thedadfirm.thedadfirmbackend.exceptions.DataException
import com.thedadfirm.thedadfirmbackend.exceptions.InternalErrorException
import com.thedadfirm.thedadfirmbackend.exceptions.NotFoundException
import com.thedadfirm.thedadfirmbackend.model.UpdateUserRequest
import com.thedadfirm.thedadfirmbackend.model.User
import org.springframework.dao.DataIntegrityViolationException
import org.springframework.data.repository.findByIdOrNull
import org.springframework.stereotype.Repository
import org.springframework.transaction.annotation.Transactional
import java.util.UUID

@Repository
class UserDatastore(
    val userRepository: UserRepository
) {
    fun createUser(user: User): User {
        try {
            return userRepository.saveAndFlush(UserEntity.from(user)).toUser()
        } catch (e: DataIntegrityViolationException) {
            throw ConflictException("Email already exist with another user")
        } catch (e: Exception) {
            throw InternalErrorException("Unexpected error occurred: ${e.message} <- ${e.cause}")
        }
    }

    fun retrieveUserByUUID(uuid: UUID): User {
        userRepository.findByIdOrNull(uuid)?.let { userEntity ->
            return userEntity.toUser()
        } ?: throw NotFoundException("User not found: $uuid")
    }

    fun retrieveUserByEmail(email: String): User {
        userRepository.findByEmail(email)?.let { userEntity ->
            return userEntity.toUser()
        } ?: throw NotFoundException("User not found: $email")
    }

    @Transactional
    fun updateUser(uuid: UUID, updateUserRequest: UpdateUserRequest): User {
        val (email, name, emailVerified, agreedToTerms, qualified) = updateUserRequest
        email?.let {
            try {
                userRepository.updateEmailByUserId(email, uuid)
            } catch (e: DataIntegrityViolationException) {
                throw ConflictException("Email already exist with another user")
            }
        }
        name?.let {
            userRepository.updateNameByUserId(name, uuid)
        }
        emailVerified?.let {
            userRepository.updateEmailVerifiedByUserId(emailVerified, uuid)
        }
        agreedToTerms?.let {
            userRepository.updateAgreedToTermsByUserId(agreedToTerms, uuid)
        }
        qualified?.let {
            userRepository.updateQualifiedByUserId(qualified, uuid)
        }
        retrieveUserByUUID(uuid).let { user: User ->
            if (updateUserRequest.updateWasSuccess(user)) {
                return user
            }
            throw DataException("Failed to update User $uuid: $updateUserRequest != $user", "UNKNOWN")
        }
    }
}
