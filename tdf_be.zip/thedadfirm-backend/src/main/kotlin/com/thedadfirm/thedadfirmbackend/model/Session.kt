package com.thedadfirm.thedadfirmbackend.model

import java.time.LocalDate
import java.util.UUID

data class Session(
    val sessionToken: String,
    val expires: LocalDate,
    val userId: UUID
)

data class UpdateSessionRequest(
    val expires: LocalDate?
)
