package com.thedadfirm.thedadfirmbackend.model

enum class AnswerAction {
    CREATE,
    SAVE
}
