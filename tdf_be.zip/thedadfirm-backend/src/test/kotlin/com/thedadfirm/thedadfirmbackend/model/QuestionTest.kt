package com.thedadfirm.thedadfirmbackend.model

import com.thedadfirm.thedadfirmbackend.exceptions.InvalidQuestionException
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import org.junit.jupiter.api.assertThrows

internal class QuestionTest {

    @Test
    fun `should throw exception if all CoreQuestion values are null`() {
        assertThrows<InvalidQuestionException> { Question() }
    }

    @Test
    fun `should throw exception if more than one CoreQuestion values are populated`() {
        assertThrows<InvalidQuestionException> {
            Question(
                multipleChoiceQuestion = MultipleChoiceQuestion("1", "Blah"),
                shortAnswerQuestion = ShortAnswerQuestion("2", "Blah")
            )
        }
    }

    @Test
    fun `should successfully create Question if only one CoreQuestion is populated`() {
        assertDoesNotThrow { Question(shortAnswerQuestion = ShortAnswerQuestion("1", "Blah")) }
        assertDoesNotThrow { Question(multipleChoiceQuestion = MultipleChoiceQuestion("2", "Blah")) }
    }
}
