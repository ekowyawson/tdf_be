package com.thedadfirm.thedadfirmbackend.model

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import java.nio.file.Path

internal class QuestionnaireTest {

    @Test
    fun `should parse questionnaire from YAML file`() {
        val file = Path.of("src/test/resources/questionnaires/test.yml").toFile()
        val expected = Questionnaire(
            name = "qualification",
            questions = listOf(
                Question(
                    multipleChoiceQuestion = null,
                    shortAnswerQuestion = ShortAnswerQuestion(
                        key = "email",
                        questionText = "What is your email?",
                        exampleInput = "name@example.com",
                        answer = null,
                        triggerSubQuestionnaire = null
                    )
                ),
                Question(
                    yesNoQuestion = YesNoQuestion(
                        key = "mother18",
                        questionText = "Is the mother of your child (or children) over the age of 18?",
                        failOnNo = true,
                        triggerSubQuestionnaire = listOf(SubQuestionnaireTrigger("Yes", questionnaireName = "county")),
                        answer = null
                    ),
                    shortAnswerQuestion = null
                ),
                Question(
                    multipleChoiceQuestion = MultipleChoiceQuestion(
                        key = "numOfChildren",
                        questionText = "How many children, under 18 years of age, do you and the mother biologically share?",
                        options = listOf("One", "Two", "Three", "More"),
                        wrongOptions = listOf("More"),
                        actionOnAnswer = null,
                        triggerSubQuestionnaire = null,
                        commentary = "The Dad Firm's process is designed to accommodate up to 3 minor children.",
                        answer = null
                    ),
                    shortAnswerQuestion = null
                )
            ),
            subQuestionnaires = listOf(
                Questionnaire(
                    name = "county",
                    questions = listOf(
                        Question(
                            multipleChoiceQuestion = null,
                            shortAnswerQuestion = ShortAnswerQuestion(
                                key = "county",
                                questionText = "Enter county of residence: ***Will be dropdown***:",
                                exampleInput = "",
                                actionOnAnswer = null,
                                answer = null,
                                triggerSubQuestionnaire = null
                            )
                        )
                    ),
                    subQuestionnaires = listOf(),
                    isComplete = false
                )
            ),
            isComplete = false
        )

        assertThat(Questionnaire.fromYamlFile(file)).isEqualTo(expected)
    }
}
