package com.thedadfirm.thedadfirmbackend.controller

import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.thedadfirm.thedadfirmbackend.datastore.DangerousRepositoryAdapter
import com.thedadfirm.thedadfirmbackend.model.Account
import com.thedadfirm.thedadfirmbackend.model.Session
import com.thedadfirm.thedadfirmbackend.model.UpdateSessionRequest
import com.thedadfirm.thedadfirmbackend.model.User
import com.thedadfirm.thedadfirmbackend.model.UserWithSession
import com.thedadfirm.thedadfirmbackend.model.VerificationToken
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.get
import org.springframework.test.web.servlet.patch
import org.springframework.test.web.servlet.post
import java.text.SimpleDateFormat
import java.time.LocalDate

@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {

    @Autowired
    lateinit var mockMvc: MockMvc

    @Autowired
    lateinit var dangerousRepositoryAdapter: DangerousRepositoryAdapter

    @BeforeEach
    fun setup() {
        dangerousRepositoryAdapter.wipe()
    }

    val mapper = jacksonObjectMapper().apply {
        this.registerModule(JavaTimeModule())
        this.dateFormat = SimpleDateFormat("yyyy-MM-dd")
        this.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
    }

    @Test
    fun `should create session`() {
        val email = "test@test.com"
        val expires = LocalDate.now()
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }
        val session = Session(sessionToken = "1234", expires = expires, userId = createdUser.id!!)

        mockMvc.post("/auth/session/create") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                session
            )
            accept = MediaType.APPLICATION_JSON
        }.andExpect {
            status { isCreated() }
            content { mapper.writeValueAsString(session) }
        }
    }

    @Test
    fun `should get session with user`() {
        val email = "test@test.com"
        val expires = LocalDate.now()
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }
        val session = Session(sessionToken = "1234", expires = expires, userId = createdUser.id!!)
        mockMvc.post("/auth/session/create") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                session
            )
            accept = MediaType.APPLICATION_JSON
        }

        mockMvc.get("/auth/session/${session.sessionToken}")
            .andExpect {
                status { isOk() }
                content { UserWithSession(user = createdUser, session = session) }
            }
    }

    @Test
    fun `should update session`() {
        val email = "test@test.com"
        val expires = LocalDate.now()
        val newExpires = LocalDate.now().plusDays(3)
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }
        val session = Session(sessionToken = "1234", expires = expires, userId = createdUser.id!!)
        mockMvc.post("/auth/session/create") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                session
            )
            accept = MediaType.APPLICATION_JSON
        }

        mockMvc.patch("/auth/session/${session.sessionToken}") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(UpdateSessionRequest(newExpires))
            accept = MediaType.APPLICATION_JSON
        }.andExpect {
            status { isOk() }
            content { mapper.writeValueAsString(session.copy(expires = newExpires)) }
        }
    }

    @Test
    fun `should create verification token`() {
        val expires = LocalDate.now()
        val verificationToken = VerificationToken("1234", token = "5678", expires = expires)
        mockMvc.post("/auth/verify/create") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                verificationToken
            )
        }.andExpect {
            status { isCreated() }
            content { mapper.writeValueAsString(verificationToken) }
        }
    }

    @Test
    fun `should use verification token`() {
        val expires = LocalDate.now()
        val verificationToken = VerificationToken("1234", token = "5678", expires = expires)
        mockMvc.post("/auth/verify/create") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                verificationToken
            )
        }
        mockMvc.post("/auth/verify/use") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(verificationToken)
        }.andExpect {
            status { isOk() }
            content { mapper.writeValueAsString(verificationToken) }
        }
    }

    @Test
    fun `should link account to user`() {
        val email = "test@test.com"
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }

        val account = Account(
            userId = createdUser.id!!,
            provider = "TEST",
            providerAccountId = "1234",
            refreshToken = "1",
            accessToken = "2",
            expiresAt = 1,
            idToken = "1234",
            scope = "SCOPE",
            sessionState = "ACTIVE",
            tokenType = "TEST"
        )
        mockMvc.post("/auth/account/link") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                account
            )
        }.andExpect {
            status { isOk() }
            content { mapper.writeValueAsString(account) }
        }
    }
}
