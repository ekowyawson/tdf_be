package com.thedadfirm.thedadfirmbackend.controller

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.ninjasquad.springmockk.MockkBean
import com.thedadfirm.thedadfirmbackend.datastore.DangerousRepositoryAdapter
import com.thedadfirm.thedadfirmbackend.datastore.UserDatastore
import com.thedadfirm.thedadfirmbackend.model.Answer
import com.thedadfirm.thedadfirmbackend.model.AnswerWithQuestionnaire
import com.thedadfirm.thedadfirmbackend.model.MultipleChoiceQuestion
import com.thedadfirm.thedadfirmbackend.model.Question
import com.thedadfirm.thedadfirmbackend.model.Questionnaire
import com.thedadfirm.thedadfirmbackend.model.ShortAnswerQuestion
import com.thedadfirm.thedadfirmbackend.model.SubQuestionnaireTrigger
import com.thedadfirm.thedadfirmbackend.model.User
import com.thedadfirm.thedadfirmbackend.model.YesNoQuestion
import io.mockk.every
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.get
import org.springframework.test.web.servlet.put
import java.util.UUID

@SpringBootTest
@AutoConfigureMockMvc
class QuestionAndAnswerControllerTest {

    @Autowired
    lateinit var mockMvc: MockMvc

    @Autowired
    lateinit var dangerousRepositoryAdapter: DangerousRepositoryAdapter

    @MockkBean
    lateinit var userDatastore: UserDatastore

    val userId: UUID = UUID.randomUUID()
    val userEmail = "test@test.com"

    @BeforeEach
    fun setup() {
        dangerousRepositoryAdapter.wipe()
        User(
            email = userEmail,
            name = "Test User",
            id = userId

        ).let { user ->
            every { userDatastore.retrieveUserByUUID(userId) } returns user
            every { userDatastore.retrieveUserByEmail(userEmail) } returns user
        }
    }

    @Test
    fun `should get questionnaire`() {
        mockMvc.get("/questions/qualification")
            .andExpect {
                status { isOk() }
                content { jacksonObjectMapper().writeValueAsString(qualification) }
            }
    }

    @Test
    fun `should answer question`() {
        val answerWithQuestionnaire = AnswerWithQuestionnaire(
            questionKey = "mother18",
            value = "Yes",
            questionnaire = "qualification"
        )
        mockMvc.put("/questions/$userId/answer") {
            contentType = MediaType.APPLICATION_JSON
            content = jacksonObjectMapper().writeValueAsString(
                answerWithQuestionnaire
            )
            accept = MediaType.APPLICATION_JSON
        }.andExpect {
            status { isCreated() }
            content { jacksonObjectMapper().writeValueAsString(answerWithQuestionnaire) }
        }
    }

    @Test
    fun `should answer question by email`() {
        val answerWithQuestionnaire = AnswerWithQuestionnaire(
            questionKey = "mother18",
            value = "Yes",
            questionnaire = "qualification"
        )
        mockMvc.put("/questions/by-email/$userEmail/answer") {
            contentType = MediaType.APPLICATION_JSON
            content = jacksonObjectMapper().writeValueAsString(
                answerWithQuestionnaire
            )
            accept = MediaType.APPLICATION_JSON
        }.andExpect {
            status { isCreated() }
            content { jacksonObjectMapper().writeValueAsString(answerWithQuestionnaire) }
        }
    }

    @Test
    fun `should get questionnaire with answers`() {
        val answerWithQuestionnaire = AnswerWithQuestionnaire(
            questionKey = "mother18",
            value = "Yes",
            questionnaire = "qualification"
        )
        mockMvc.put("/questions/$userId/answer") {
            contentType = MediaType.APPLICATION_JSON
            content = jacksonObjectMapper().writeValueAsString(
                answerWithQuestionnaire
            )
            accept = MediaType.APPLICATION_JSON
        }
        val qualificationWithAnswer = qualification.copy().apply {
            this.applyAnswers(listOf(Answer("mother18", "Yes")))
        }
        mockMvc.get("/questions/qualification/$userId")
            .andExpect {
                status { isOk() }
                content { jacksonObjectMapper().writeValueAsString(qualificationWithAnswer) }
            }
    }

    @Test
    fun `should get questionnaire with answers by email`() {
        val answerWithQuestionnaire = AnswerWithQuestionnaire(
            questionKey = "mother18",
            value = "Yes",
            questionnaire = "qualification"
        )
        mockMvc.put("/questions/by-email/$userEmail/answer") {
            contentType = MediaType.APPLICATION_JSON
            content = jacksonObjectMapper().writeValueAsString(
                answerWithQuestionnaire
            )
            accept = MediaType.APPLICATION_JSON
        }
        val qualificationWithAnswer = qualification.copy().apply {
            this.applyAnswers(listOf(Answer("mother18", "Yes")))
        }
        mockMvc.get("/questions/qualification/by-email/$userEmail")
            .andExpect {
                status { isOk() }
                content { jacksonObjectMapper().writeValueAsString(qualificationWithAnswer) }
            }
    }

    val qualification = Questionnaire(
        name = "qualification",
        questions = listOf(
            Question(
                multipleChoiceQuestion = null,
                shortAnswerQuestion = ShortAnswerQuestion(
                    key = "email",
                    questionText = "What is your email?",
                    exampleInput = "name@example.com",
                    answer = null,
                    triggerSubQuestionnaire = null
                )
            ),
            Question(
                yesNoQuestion = YesNoQuestion(
                    key = "mother18",
                    questionText = "Is the mother of your child (or children) over the age of 18?",
                    failOnNo = true,
                    triggerSubQuestionnaire = listOf(SubQuestionnaireTrigger("Yes", questionnaireName = "county")),
                    answer = null
                ),
                shortAnswerQuestion = null
            ),
            Question(
                multipleChoiceQuestion = MultipleChoiceQuestion(
                    key = "numOfChildren",
                    questionText = "How many children, under 18 years of age, do you and the mother biologically share?",
                    options = listOf("One", "Two", "Three", "More"),
                    wrongOptions = listOf("More"),
                    actionOnAnswer = null,
                    triggerSubQuestionnaire = null,
                    commentary = "The Dad Firm's process is designed to accommodate up to 3 minor children.",
                    answer = null
                ),
                shortAnswerQuestion = null
            )
        ),
        subQuestionnaires = listOf(
            Questionnaire(
                name = "county",
                questions = listOf(
                    Question(
                        multipleChoiceQuestion = null,
                        shortAnswerQuestion = ShortAnswerQuestion(
                            key = "county",
                            questionText = "Enter county of residence: ***Will be dropdown***:",
                            exampleInput = "",
                            actionOnAnswer = null,
                            answer = null,
                            triggerSubQuestionnaire = null
                        )
                    )
                ),
                subQuestionnaires = listOf(),
                isComplete = false
            )
        ),
        isComplete = false
    )
}
