package com.thedadfirm.thedadfirmbackend.controller

import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.thedadfirm.thedadfirmbackend.datastore.DangerousRepositoryAdapter
import com.thedadfirm.thedadfirmbackend.model.Account
import com.thedadfirm.thedadfirmbackend.model.UpdateUserRequest
import com.thedadfirm.thedadfirmbackend.model.User
import com.thedadfirm.thedadfirmbackend.model.UserProvider
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.get
import org.springframework.test.web.servlet.patch
import org.springframework.test.web.servlet.post
import java.text.SimpleDateFormat
import java.time.LocalDate

@SpringBootTest
@AutoConfigureMockMvc
class UserControllerTest {

    @Autowired
    lateinit var mockMvc: MockMvc

    @Autowired
    lateinit var dangerousRepositoryAdapter: DangerousRepositoryAdapter

    @BeforeEach
    fun setup() {
        dangerousRepositoryAdapter.wipe()
    }

    val mapper = jacksonObjectMapper().apply {
        this.registerModule(JavaTimeModule())
        this.dateFormat = SimpleDateFormat("yyyy-MM-dd")
        this.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
    }

    @Test
    fun `should create user`() {
        val email = "test@test.com"
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andExpect {
            status { isCreated() }
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }

        assertThat(createdUser.email).isEqualTo(email)
    }

    @Test
    fun `should get user by id`() {
        val email = "test@test.com"
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }

        mockMvc.get("/user/${createdUser.id}").andExpect {
            status { isOk() }
            content { mapper.writeValueAsString(createdUser) }
        }
    }

    @Test
    fun `should get user by email`() {
        val email = "test@test.com"
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }

        mockMvc.get("/user/by-email/$email").andExpect {
            status { isOk() }
            content { mapper.writeValueAsString(createdUser) }
        }
    }

    @Test
    fun `should get user by account`() {
        val email = "test@test.com"
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }

        val account = mockMvc.post("/auth/account/link") {
            contentType = MediaType.APPLICATION_JSON
            content = """
                {
                    "userId": "${createdUser.id}",
                    "provider": "Account-Test",
                    "providerAccountId": "1234",
                    "refreshToken": "ref",
                    "accessToken": "acc",
                    "expiresAt": 1,
                    "tokenType": "TEST",
                    "scope": "Limited",
                    "idToken": "id-token",
                    "sessionState": "ACTIVE"
                }
            """.trimIndent()
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue<Account>(contentString)
        }

        mockMvc.get("/user/by-account") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                UserProvider(account.providerAccountId, account.provider)
            )
            accept = MediaType.APPLICATION_JSON
        }.andExpect {
            status { isOk() }
            content { mapper.writeValueAsString(createdUser) }
        }
    }

    @Test
    fun `should update user`() {
        val email = "test@test.com"
        val emailVerified = LocalDate.now()
        val createdUser: User = mockMvc.post("/user") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                User(email = email)
            )
            accept = MediaType.APPLICATION_JSON
        }.andReturn().response.contentAsString.let { contentString ->
            return@let mapper.readValue(contentString)
        }

        val updateUserRequest = UpdateUserRequest(
            email = "another@test.com",
            name = "Tim Tester",
            emailVerified = emailVerified,
            agreedToTerms = true,
            qualified = true
        )
        mockMvc.patch("/user/${createdUser.id}") {
            contentType = MediaType.APPLICATION_JSON
            content = mapper.writeValueAsString(
                updateUserRequest
            )
            accept = MediaType.APPLICATION_JSON
        }.andExpect {
            status { isOk() }
            content {
                mapper.writeValueAsString(
                    User(
                        id = createdUser.id,
                        email = updateUserRequest.email!!,
                        name = updateUserRequest.name,
                        emailVerified = emailVerified,
                        agreedToTerms = updateUserRequest.agreedToTerms!!,
                        qualified = updateUserRequest.qualified!!
                    )
                )
            }
        }
    }
}
